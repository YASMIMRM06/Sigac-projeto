<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    @vite(['resource/js/app.js'])
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="text-center">
        <button class="btn btn-primary" id="btn">Click me!</button>
    </div>
</body>
</html>